

UI (Counter Component) -> 
Dispatch(action)->
Slice Reducer(update State)-> 
Store(Holds updated global State)->
rerender the UI using useSelector